﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WithoutChain
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeHandlers();
        }

        private Support1 support1;
        private Support2 support2;
        private Support3 support3;

        private void InitializeHandlers()
        {
            support1 = new Support1(textBox1);
            support2 = new Support2(textBox1);
            support3 = new Support3(textBox1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            support1.HandleRequest();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            support2.HandleRequest();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            support3.HandleRequest();
        }

        public interface IHandler
        {
            void HandleRequest();
        }

        public class Support1 : IHandler
        {
            private TextBox _textBox;

            public Support1(TextBox textBox)
            {
                _textBox = textBox;
            }

            public void HandleRequest()
            {
                _textBox.Clear();
                _textBox.AppendText("Соединяем Вас со специалистом 1\n");
            }
        }

        public class Support2 : IHandler
        {
            private TextBox _textBox;

            public Support2(TextBox textBox)
            {
                _textBox = textBox;
            }

            public void HandleRequest()
            {
                _textBox.Clear();
                _textBox.AppendText("Соединяем Вас со специалистом 2\n");
            }
        }

        public class Support3 : IHandler
        {
            private TextBox _textBox;

            public Support3(TextBox textBox)
            {
                _textBox = textBox;
            }

            public void HandleRequest()
            {
                _textBox.Clear();
                _textBox.AppendText("Соединяем Вас со специалистом 3\n");
            }
        }
    }
}
