﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChainOfResponsibility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeHandlers();
        }

        CLient client1 = new CLient();
        private Support1 support1;
        private Support2 support2;
        private Support3 support3;
        ComboBox cb;
        private void InitializeHandlers()
        {
            // Инстанцируем классы-обработчики
            support1 = new Support1(textBox1);
            support2 = new Support2(textBox1);
            support3 = new Support3(textBox1);

            // Устанавливаем последовательность в цепочке
            support1.SetSuccessor(support2);
            support2.SetSuccessor(support3);
            cb = comboBox1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            client1.SendRequest(support1, cb.Text);
        }

        public class CLient
        {
            public void SendRequest(IHandler support, string text)
            {
                support.HandleRequest(text);
            }
        }

        public interface IHandler { 
            void SetSuccessor(IHandler successor);
            void HandleRequest(string request);
        }

        public class Support1 : IHandler
        {
            private IHandler _successor;
            private TextBox _textBox;

            public Support1(TextBox textBox)
            {
                _textBox = textBox;
            }

            public void SetSuccessor(IHandler successor)
            {
                _successor = successor;
            }

            public void HandleRequest(string request)
            {
                if (request == "Проблема с подключением к сети")
                {
                    _textBox.Clear();
                    _textBox.AppendText("Соединяем Вас со специалистом 1\n");
                }
                else if (_successor != null)
                {
                    _successor.HandleRequest(request);
                }
            }
        }

        public class Support2 : IHandler
        {
            private IHandler _successor;
            private TextBox _textBox;

            public Support2(TextBox textBox)
            {
                _textBox = textBox;
            }

            public void SetSuccessor(IHandler successor)
            {
                _successor = successor;
            }

            public void HandleRequest(string request)
            {
                if (request == "Неполадки в работе программы")
                {
                    _textBox.Clear();
                    _textBox.AppendText("Соединяем Вас со специалистом 2\n");
                }
                else if (_successor != null)
                {
                    _successor.HandleRequest(request);
                }
            }
        }

        public class Support3 : IHandler
        {
            private IHandler _successor;
            private TextBox _textBox;

            public Support3(TextBox textBox)
            {
                _textBox = textBox;
            }

            public void SetSuccessor(IHandler successor)
            {
                _successor = successor;
            }

            public void HandleRequest(string request)
            {
                if (request == "Проблема с установкой ПО")
                {
                    _textBox.Clear();
                    _textBox.AppendText("Соединяем Вас со специалистом 3\n");
                }
                else if (_successor != null)
                {
                    _successor.HandleRequest(request);
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
    }
}
